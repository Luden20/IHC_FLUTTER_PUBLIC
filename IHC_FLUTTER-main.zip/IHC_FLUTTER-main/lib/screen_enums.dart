enum screens {
  home(0),
  join(1),
  create(2),
  profile(3);

  const screens(this.value);

  final int value;
}
