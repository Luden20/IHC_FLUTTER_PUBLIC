package com.ihc.appihv

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
